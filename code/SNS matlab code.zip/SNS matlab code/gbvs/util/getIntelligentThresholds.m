function threshs = getIntelligentThresholds( vals );

threshs = unique(vals) - 1e-16;
    
    
    
    
    
